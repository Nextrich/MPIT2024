from kivy.app import App
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.relativelayout import RelativeLayout 
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.graphics import Rectangle
import sqlite3
Window.size = (428, 926)
#129307!
class MyApp(App):
	def set_bg(self, *args):
		self.root_window.bind(size=self.do_resize)
		with self.root_window.canvas.before:
			self.bg = Rectangle(source='UI\\bg.jpg', pos=(0,0), size=(self.root_window.size))
	
	def __init__(self):
		super().__init__()

	def on_focus(self, instance, value):
		if value and self.reg_name.text == 'Имя' or self.reg_name.text == 'Пусто':
			self.reg_name.text = ''
			self.reg_name.color = 'black'
		elif value and self.reg_email.text == 'Эл. почта' or self.reg_email.text == 'Пусто':
			self.reg_email.text = ''
			self.reg_email.color = 'black'
		elif value and self.reg_pass.text == 'Пароль' or self.reg_pass.text == 'Пароли не совпадают' or self.reg_pass.text == 'Пусто'or self.reg_pass.text == 'Неправильное имя или пароль':
			self.reg_pass.text = ''
			self.reg_pass.color = 'black'
		elif value and self.reg_pass_confirm.text == 'Пароль ещё раз' or self.reg_pass.text == 'Пароли не совпадают' or self.reg_pass_confirm.text == 'Пусто':
			self.reg_pass_confirm.text = ''
			self.reg_pass_confirm.color = 'black'

		else:
			if self.reg_name.text == '':
				if self.reg_name.text == '':
					self.reg_name.text = 'Имя'
				elif self.reg_name.text == ' ':
					a = self.reg_name.text
					self.reg_name.text = a.replace(' ', '')
			if self.reg_email.text == '':
				if self.reg_email.text == '':
					self.reg_email.text = 'Эл. почта'
				elif self.reg_email.text == ' ':
					a = self.reg_email.text
					self.reg_email.text = a.replace(' ', '')
			if self.reg_pass.text == '':
				if self.reg_pass.text == '':
					self.reg_pass.text = 'Пароль'
				elif self.reg_pass.text == ' ':
					a = self.reg_pass.text
					self.reg_pass.text = a.replace(' ', '')
			if self.reg_pass_confirm.text == '':
				if self.reg_pass_confirm.text == '':
					self.reg_pass_confirm.text = 'Пароль ещё раз'
				elif self.reg_pass_confirm.text == ' ':
					a = self.reg_pass_confirm.text
					self.reg_pass_confirm.text = a.replace(' ', '')

	def do_resize(self, *args):
		self.bg.size = self.root_window.size
	
	def login_account(self, instance):
		if self.reg_name.text == '' or self.reg_name.text == 'Пусто':	#name(login)
			self.reg_name.text = 'Пусто'
		elif self.reg_pass.text == '' or self.reg_pass.text == 'Пусто':	#pass(login)
			self.reg_pass.text = 'Пусто'

		elif self.reg_name.text != '' and self.reg_pass != '':
			dbn = 'app_users_data.db'
			conn = sqlite3.connect(dbn)
			cursor = conn.cursor()
			sqlite_names = """SELECT name FROM user_private_data"""
			cursor.execute(sqlite_names)
			sqlite_names = cursor.fetchall()
			sqlite_pass = """SELECT password FROM user_private_data"""
			cursor.execute(sqlite_pass)
			sqlite_pass = cursor.fetchall()
			conn.commit()
			conn.close()

			key = False
			name = self.reg_name.text.replace(' ', '')
			password = self.reg_pass.text.replace(' ', '')
			for a in sqlite_names:
				print(a[0])
				if a[0] == name:
					for b in sqlite_pass:
						if password == b[0]:
							key = True
							self.reg_lbl.opacity =0
							self.reg_name.opacity =0
							self.reg_email.opacity =0
							self.reg_pass.opacity =0
							self.reg_pass_confirm.opacity =0
							self.next_reg_btn.opacity =0
							self.reg_lbl.size_hint=(.0, .0)
							self.reg_lbl.size_hint = (.0, .0)
							self.reg_name.size_hint = (.0, .0)
							self.reg_pass.size_hint = (.0, .0)
							self.reg_email.size_hint = (.0, .0)
							self.reg_pass_confirm.size_hint = (.0, .0)
							self.next_reg_btn.size_hint = (.0, .0)

							self.welcome.opacity =1
							self.card_salan.opacity =1
							self.card_ugus.opacity =1
							self.card_teeth.opacity =1
							self.card_megalits.opacity =1
							self.card_shoria.opacity =1
							self.small_full_map.opacity =1
				if key == False:
					self.reg_pass.text  ='Неправильное имя или пароль'

	def register_accounts(self, instance):
		self.reg_name.text = self.reg_name.text.replace(' ', '')
		self.reg_email.text = self.reg_email.text.replace(' ', '')
		if self.reg_pass.text != self.reg_pass_confirm.text:

			self.reg_pass_confirm.color = 'red'
			self.reg_pass.color = 'red'
			self.reg_pass_confirm.text = 'Пароли не совпадают'
			self.reg_pass.text = 'Пароли не совпадают'
			self.reg_pass_confirm.color = 'black'
			self.reg_pass.color = 'black'

		elif self.reg_name.text == '' or self.reg_name.text == 'Пусто':	#name(login)
			self.reg_name.text = 'Пусто'
		elif self.reg_pass.text == '' or self.reg_pass.text == 'Пусто':	#pass(login)
			self.reg_pass.text = 'Пусто'
		elif self.reg_email.text == '' or self.reg_email.text == 'Пусто': #email(register)
			self.reg_email.text = 'Пусто'
		elif self.reg_pass_confirm.text == '' or self.reg_pass_confirm.text == 'Пусто': #pass_confirm(register)
			self.reg_pass_confirm.text = 'Пусто'

		else: #INSERT INTO user_private_data(name,  email,  password) VALUES ('Алёна',  'skudarnovaalena0@gmail.com',  'skudarnova2009')
			dbn = 'app_users_data.db'
			conn = sqlite3.connect(dbn)
			cursor = conn.cursor()
			sqlite_users = f"""INSERT INTO user_private_data(name,  email,  password) VALUES ('{self.reg_name.text}',  '{self.reg_email.text}',  '{self.reg_pass.text}')"""
			cursor.execute(sqlite_users)
			conn.commit()
			conn.close()
			file = open('local.txt', "w+")
			file.write(f'username:{self.reg_name.text};email:{self.reg_email.text};password:{self.reg_pass.text}')
			file.close()
			self.reg_lbl.opacity =0
			self.reg_name.opacity =0
			self.reg_email.opacity =0
			self.reg_pass.opacity =0
			self.reg_pass_confirm.opacity =0
			self.next_reg_btn.opacity =0
			self.reg_lbl.size_hint = (.0, .0)
			self.reg_lbl.size_hint = (.0, .0)
			self.reg_name.size_hint = (.0, .0)
			self.reg_pass.size_hint = (.0, .0)
			self.reg_email.size_hint = (.0, .0)
			self.reg_pass_confirm.size_hint = (.0, .0)
			self.next_reg_btn.size_hint = (.0, .0)

			self.welcome.opacity =1
			self.card_salan.opacity =1
			self.card_ugus.opacity =1
			self.card_teeth.opacity =1
			self.card_megalits.opacity =1
			self.card_shoria.opacity =1
			self.small_full_map.opacity =1

	def change_reg(self,instance):
		self.about_lbl.opacity = 0
		self.about_text.opacity = 0
		self.register.opacity = 0
		self.if_register.opacity = 0
		self.login.opacity = 0
		self.about_lbl.size_hint = (.0, .0)
		self.about_text.size_hint = (.0, .0)
		self.register.size_hint = (.0, .0)
		self.if_register.size_hint = (.0, .0)
		self.login.size_hint = (.0, .0)

		self.reg_lbl.opacity =1
		self.reg_name.opacity =1
		self.reg_email.opacity =1
		self.reg_pass.opacity =1
		self.reg_pass_confirm.opacity =1
		self.next_reg_btn.opacity =1

		self.reg_lbl.text = 'Регистрация'
		self.next_reg_btn.bind(on_press=self.register_accounts)
	
	def change_log(self, instance):
		self.about_lbl.opacity =0
		self.about_text.opacity =0
		self.register.opacity =0
		self.if_register.opacity =0
		self.login.opacity =0
		self.about_lbl.size_hint =(.0,.0)
		self.about_text.size_hint =(.0,.0)
		self.register.size_hint =(.0,.0)
		self.if_register.size_hint =(.0,.0)
		self.login.size_hint =(.0,.0)

		self.reg_lbl.opacity =1
		self.reg_name.opacity =1
		self.reg_pass.opacity =1
		self.next_reg_btn.opacity =1

		self.reg_lbl.text = 'Вход'
		self.next_reg_btn.bind(on_press=self.login_account)

	def change_welcome(self, instance):
		self.logo.opacity =0
		self.reg_lbl.opacity =0
		self.reg_name.opacity =0
		self.reg_email.opacity =0
		self.reg_pass.opacity =0
		self.reg_pass_confirm.opacity =0
		self.next_reg_btn.opacity =0
		self.logo.size_hint=(.0, .0)
		self.logo.pos_hint ={'center_x':10}
		self.logo.pos =(1000,1000)
		self.reg_lbl.size_hint = (.0, .0)
		self.reg_lbl.size_hint = (.0, .0)
		self.reg_name.size_hint = (.0, .0)
		self.reg_pass.size_hint = (.0, .0)
		self.reg_email.size_hint = (.0, .0)
		self.reg_pass_confirm.size_hint = (.0, .0)
		self.next_reg_btn.size_hint = (.0, .0)


		self.welcome.opacity =1
		self.card_salan.opacity =1
		self.card_ugus.opacity =1
		self.card_teeth.opacity =1
		self.card_megalits.opacity =1
		self.card_shoria.opacity =1
		self.small_full_map.opacity =1

	def build(self):
		Clock.schedule_once(self.set_bg, 0)
		buttons_layout = RelativeLayout()
		#image = Image(source='logo.jpg')

		#account_list---------------------------------------------------------------------------------------------------------------------------------
		self.welcome = Label(text='Междуреченский турист', pos_hint ={'center_x':.5}, pos =(214.0, 900.0), size_hint =(.7, .4), opacity=0)
		self.card_salan = Button(pos_hint ={'center_x':.5}, background_normal='UI\\salan.png', size_hint =(1.0, .12), pos =(214.0, 850.0), border=(10, 10, 10, 10), opacity=0)
		self.card_ugus = Button(pos_hint ={'center_x':.5}, background_normal='UI\\Ugus.png', size_hint =(1.0, .12), pos =(214.0, 700.0), border=(10, 10, 10, 10), opacity=0)
		self.card_teeth = Button(pos_hint ={'center_x':.5}, background_normal='UI\\teeth.png', size_hint =(1.0, .12), pos =(214.0, 550.0), border=(10, 10, 10, 10), opacity=0)
		self.card_megalits = Button(pos_hint ={'center_x':.5}, background_normal='UI\\megalits.png', size_hint =(1.0, .12), pos =(214.0, 400.0), border=(10, 10, 10, 10), opacity=0)
		self.card_shoria = Button(pos_hint ={'center_x':.5}, background_normal='UI\\Shoria.png', size_hint =(1.0, .12), pos =(214.0, 250.0), border=(10, 10, 10, 10), opacity=0)
		self.small_full_map = Button(pos_hint ={'center_x':.5}, background_normal='UI\\map_mini.png', size_hint =(1.0, .25), pos =(214.0, 10.0), border=(10, 10, 10, 10), opacity=0)

		#front----------------------------------------------------------------------------------------------------------------------------------------
		buttons_layout.add_widget(self.welcome)
		buttons_layout.add_widget(self.card_salan)
		buttons_layout.add_widget(self.card_ugus)
		buttons_layout.add_widget(self.card_teeth)
		buttons_layout.add_widget(self.card_megalits)
		buttons_layout.add_widget(self.card_shoria)
		buttons_layout.add_widget(self.small_full_map)

		#register_form--------------------------------------------------------------------------------------------------------------------------------
		self.reg_lbl = Label(text='Регистрация', bold=True, pos_hint ={'center_x':.5}, size_hint =(.7, .4), pos =(214.0, 425.0), opacity=0)
		self.reg_name = TextInput(size_hint =(.7, .03), multiline = False, pos =(214.0, 570.0), pos_hint ={'center_x':.5}, text='Имя', opacity=0)
		self.reg_email = TextInput(size_hint =(.7, .03), pos =(214.0, 510.0), multiline = False, pos_hint ={'center_x':.5}, text='Эл. почта', opacity=0)
		self.reg_pass = TextInput(size_hint =(.7, .03), pos =(214.0, 450.0), multiline = False, pos_hint ={'center_x':.5}, text='Пароль', opacity=0)
		self.reg_pass_confirm = TextInput(size_hint =(.7, .03), pos =(214.0, 390.0), multiline = False, pos_hint ={'center_x':.5}, text='Пароль ещё раз', opacity=0)
		self.next_reg_btn = Button(pos_hint ={'center_x':.5}, background_normal='UI\\next.png', size_hint =(.55, .1), pos =(214.0, 250.0), opacity=0)

		self.reg_name.bind(focus=self.on_focus)
		self.reg_email.bind(focus=self.on_focus)
		self.reg_pass.bind(focus=self.on_focus)
		self.reg_pass_confirm.bind(focus=self.on_focus)

		#front----------------------------------------------------------------------------------------------------------------------------------------
		buttons_layout.add_widget(self.reg_lbl)
		buttons_layout.add_widget(self.reg_name)
		buttons_layout.add_widget(self.reg_email)
		buttons_layout.add_widget(self.reg_pass)
		buttons_layout.add_widget(self.reg_pass_confirm)
		buttons_layout.add_widget(self.next_reg_btn)

		#first_page-----------------------------------------------------------------------------------------------------------------------------------
		self.logo = Button(text='', color='black', pos_hint ={'center_x':.5}, background_normal='UI\\logo.jpg', size_hint =(.7, .4), pos =(214.0, 675.0), opacity=1)
		self.about_lbl = Label(text='О нас:', bold=True, size_hint =(.7, .4), pos =(214.0, 385.0), pos_hint ={'center_x':.5})   #, background_normal='btn_bg.png')
		self.about_text = Label(text='Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.', text_size=(350, None), size_hint =(.7, .4), pos =(214.0, 325.0), pos_hint ={'center_x':.5})
		self.if_register = Label(text='Уже есть аккаунт?', size_hint =(.7, .4), pos =(214.0, -5.0), pos_hint ={'center_x':.425})
		self.login = Button(text='Вход', bold=True, size_hint =(.1, .01), pos =(214.0, 202.0), pos_hint ={'center_x':.625}, background_normal='UI\\squre.jpg')
		self.register = Button(text='', pos_hint ={'center_x':.5}, background_normal='UI\\reg_btn.jpg', size_hint =(.85, .15), pos =(214.0, 225.0))

		self.register.bind(on_press=self.change_reg)
		self.login.bind(on_press=self.change_log)
		#front----------------------------------------------------------------------------------------------------------------------------------------
		buttons_layout.add_widget(self.logo)
		buttons_layout.add_widget(self.about_lbl)
		buttons_layout.add_widget(self.about_text)
		buttons_layout.add_widget(self.register)
		buttons_layout.add_widget(self.if_register)
		buttons_layout.add_widget(self.login)

		return buttons_layout
		
if __name__ == '__main__':
	MyApp().run()
